<?php

namespace App\Http\Controllers;

use App\Gejala;
use App\Hasil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class perhitungan extends Controller
{
    public function main()
    {
      return view('mainpage');
    }

    public function hasil()
    {
      return view('hasil');
    }

    public function test()
    {
      $symp = DB::table('gejala') ->get();
      return view('mainpage', ['symp' => $symp]);
    }

    public function submittest(Request $request)
   {
       $gejala = count($request->iteration1);
       $sum  = 0;
       $sum2 = 0;
       $sum4 = 0;
       $new = Hasil::orderBy('id', 'desc')->first();

       for($i=0; $i < $gejala ; $i++) {
           $gejalas = new Hasil;
           $gejalas->id_gejala   = $request->id_gejala[$i];
           $gejalas->nama        = $request->nama;
           $it1     = $gejalas->iteration1  = $request->iteration1[$i];

           $sum       += $it1;
           $sum1       = $gejalas->sum1  = $sum;
           $max        = $gejalas->max   = $new->sum1;
           $maxval1    = round(max($sum1,$sum1),4);
           $it2        = $gejalas->iteration2  = round($it1/$max,4);
           $it3        = $gejalas->iteration3  = round($it1*$it2,4);
           $sum2      += $it3;
           $sum3       = $gejalas->sum2 = $sum2;
           $max2       = $gejalas->max2 = $new->sum2;
           $it4        = $gejalas->iteration4  = round($it3/$max2,4);
           $bayes      = $gejalas->bayes       = round($it1*$it4,4);
           $sum4      += $bayes;
           $lastsum    = $gejalas->lastvalue  = $sum4;
           $persentase = $gejalas->persentase = ($new->lastvalue)*100;

           $gejalas->save();
       }

       $data    = Hasil::where('nama',$request->nama)->first();
       $hasil   = Hasil::where('nama',$request->nama)->get();
       return view('hasil',['data'=>$data,'hasil'=>$hasil,'max'=>$max,'max2'=>$max2,'persentase'=>$persentase]);
   }

}
