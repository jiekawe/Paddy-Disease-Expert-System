<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hasil extends Model
{
  protected $table = 'hasil';
  protected $primaryKey = 'id';
  public $timestamps = false;
  protected $guarded = [];
}
