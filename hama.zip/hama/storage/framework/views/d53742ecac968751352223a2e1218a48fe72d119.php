<?php echo $__env->make('include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main>
  <div class="container">
       <div class="row">
         <div class="col s6 m12">
           <div class="card horizontal">
             <div class="card-stacked">
               <div class="card-content">
                 <h5>Nama = <?php echo e($data->nama); ?></h5>

                 <h5>Index Gejala & Nilai = </h5>
                 <table>
                   <thead>
                     <tr>
                       <th>ID Gejala</th>
                       <th>Nilai Kepastian P(E|Hi)</th>
                       <th>P(Hi)</th>
                       <th>P(Hi)*P(Hi|E) tanpa evidence</th>
                       <th>P(Hi|E) dengan evidence</th>
                       <th>Nilai Bayes</th>
                     </tr>
                   </thead>
                   <tbody>
                     <?php $__currentLoopData = $hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasils => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                          <td><?php echo e($value->id_gejala); ?></td>
                          <td><?php echo e($value->iteration1); ?></td>
                          <td><?php echo e($value->iteration2); ?></td>
                          <td><?php echo e($value->iteration3); ?></td>
                          <td><?php echo e($value->iteration4); ?></td>
                          <td><?php echo e($value->bayes); ?></td>
                       </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                   <tfoot>
                      <tr>
                        <td>Jumlah</td>
                        <td><?php echo e($max); ?></td>
                        <td></td>
                        <td><?php echo e($max2); ?></td>
                        <td></td>
                        <td>Persentase Total = <?php echo e($persen = $persentase); ?>%</td>
                      </tr>
                    </tfoot>
                 </table>

                    <div class="card-panel orange">
                      <span class="white-text">
                        <?php if($persen < '51.00'): ?>
                        <h5>Tanaman Padi Kemungkinan Terserang Hama dan Penyakit Pada Batang</h5>
                        <?php elseif($persen >= '51.00'): ?>
                        <h5>Tanaman Padi Kemungkinan Terserang Hama dan Penyakit Pada Daun</h5>
                        <?php elseif($persen >= '80.00'): ?>
                        <h5>Tanaman Padi Kemungkinan Terserang Hama dan Penyakit Pada Bulir</h5>
                        <?php elseif($persen >= '90.00'): ?>
                        <h5>Tanaman Padi Kemungkinan Terserang Hama dan Penyakit Pada Malai</h5>
                        <?php else: ?>
                        <h5>Silahkan Input Ulang</h5>
                        <?php endif; ?>
                      </span>
                    </div>

               </div>
               <div class="card-action">
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>
</main>
<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
