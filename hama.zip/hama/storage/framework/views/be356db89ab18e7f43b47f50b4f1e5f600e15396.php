<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('css\app.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('css\materialize.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('css\materialize.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('css\footer.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('https://fonts.googleapis.com/icon?family=Material+Icons')); ?>">
		<script type="text/javascript" src="<?php echo e(url('js\app.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(url('js\materialize.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(url('js\materialize.min.js')); ?>"></script>
	</head>
	<body>

		<nav class="pushpin-nav" style="z-index: 5">
			<div class="nav-wrapper light-blue">
				<a href="/home" class="brand-logo">Sistem Pakar Penyakit Tumbuhan</a>
			</div>
		</nav>
