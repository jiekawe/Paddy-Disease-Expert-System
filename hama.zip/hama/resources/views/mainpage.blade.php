@include('include.header')
<main>
  <form action="../submittest" method="post" enctype="multipart/form-data">
            <div class="container">

                <h2>Form Diagnosa</h2>
                <div class="container">
                  <div class="row">
                      <div class="blue-text text-darken-2">
                        <div class="card-content black-text">
                          <div class="input-field">
                            <input name="nama" type="text">
                            <label for="nama">Nama </label>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>

                {{csrf_field()}}
                <table class="highlight col s12; striped">
                    <thead class="blue-grey lighten-2 white-text">
                    <tr>
                        <th>ID</th>
                        <th>Pertanyaan Gejala</th>
                        <th>Durasi</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($symp as $symps => $data)
                        <tr>
                          <td>
                            <div class="input-field">
                                <input name="id_gejala[]" readonly value="{{$data->id_gejala}}" type="text" class="validate">
                            </div>
                          </td>

                            <td class="collapsible popout">{{$data->pertanyaan}}</td>
                            <td id="selections">
                                <select name="iteration1[]" multiple="multiple">
                                    <option disabled selected>Pilihan</option>
                                    <option value="0">Tidak Tahu</option>
                                    <option value="0.2">Tidak Pasti</option>
                                    <option value="0.4">Kurang Pasti</option>
                                    <option value="0.6">Cukup Pasti</option>
                                    <option value="0.8">Hampir Pasti</option>
                                    <option value="1">Pasti</option>
                                </select>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        </div>
            <div style="text-align:center">
              <input class="waves-effect deep-purple accent-2 waves-light btn" type="submit" value="Submit">
              <a href="pasien" style="position: static" class="waves-effect yellow darken-3 waves-light btn">Cancel</a>
            </div>
            <!-- <input type="submit"  name="Submit" value="Tambah" > -->

            {{ csrf_field() }}
            <input type="hidden" name="_method" value="PUT">
    </form>

</main>
@include('include.footer')
