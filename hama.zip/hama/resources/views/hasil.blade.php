@include('include.header')
<main>
  <div class="container">
       <div class="row">
         <div class="col s6 m12">
           <div class="card horizontal">
             <div class="card-stacked">
               <div class="card-content">
                 <h5>Nama = {{$data->nama}}</h5>

                 <h5>Index Gejala & Nilai = </h5>
                 <table>
                   <thead>
                     <tr>
                       <th>ID Gejala</th>
                       <th>Nilai Kepastian P(E|Hi)</th>
                       <th>P(Hi)</th>
                       <th>P(Hi)*P(Hi|E) tanpa evidence</th>
                       <th>P(Hi|E) dengan evidence</th>
                       <th>Nilai Bayes</th>
                     </tr>
                   </thead>
                   <tbody>
                     @foreach($hasil as $hasils => $value)
                       <tr>
                          <td>{{$value->id_gejala}}</td>
                          <td>{{$value->iteration1}}</td>
                          <td>{{$value->iteration2}}</td>
                          <td>{{$value->iteration3}}</td>
                          <td>{{$value->iteration4}}</td>
                          <td>{{$value->bayes}}</td>
                       </tr>
                     @endforeach
                   </tbody>
                   <tfoot>
                      <tr>
                        <td>Jumlah</td>
                        <td>{{$max}}</td>
                        <td></td>
                        <td>{{$max2}}</td>
                        <td></td>
                        <td>Persentase Total = {{$persen = $persentase}}%</td>
                      </tr>
                    </tfoot>
                 </table>

                    <div class="card-panel orange">
                      <span class="white-text">
                        @if ($persen < '51.00')
                        <h5>Tanaman Padi Kemungkinan Terserang Hama dan Penyakit Pada Batang</h5>
                        @elseif($persen >= '51.00')
                        <h5>Tanaman Padi Kemungkinan Terserang Hama dan Penyakit Pada Daun</h5>
                        @elseif($persen >= '80.00')
                        <h5>Tanaman Padi Kemungkinan Terserang Hama dan Penyakit Pada Bulir</h5>
                        @elseif($persen >= '90.00')
                        <h5>Tanaman Padi Kemungkinan Terserang Hama dan Penyakit Pada Malai</h5>
                        @else
                        <h5>Silahkan Input Ulang</h5>
                        @endif
                      </span>
                    </div>

               </div>
               <div class="card-action">
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>
</main>
@include('include.footer')
