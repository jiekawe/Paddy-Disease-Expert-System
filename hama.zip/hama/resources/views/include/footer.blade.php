<footer class="page-footer light-blue">

	<div class="footer-copyright center">
		<div class="container">
			© 2018 Copyright Jiekawe
		</div>
	</div>
</footer>
<script>
$(document).ready(function(){
$('.modal').modal();
});
  $(document).ready(function() {
    $('select').material_select();
  });
</script>
</body>
</html>
